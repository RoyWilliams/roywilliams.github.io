import java.applet.Applet;
import java.util.*;
import java.awt.*;
import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.geometry.Cone;
import com.sun.j3d.utils.geometry.Sphere;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.behaviors.mouse.*;

public class S3D extends Frame {

    // 3D Canvas
    Canvas3D           canvas;

    // Scene Graph
    BranchGroup        rootBG;
    TransformGroup     sceneTG;
    BranchGroup        baseBG;
    BranchGroup        stellBG;

    // Other stuff
    BoundingSphere     bounds;
    Transform3D        sceneTransform;

    // Colors for lights and objects
    Color3f aColor     = new Color3f(0.2f, 0.2f, 0.2f);
    Color3f eColor     = new Color3f(0.0f, 0.0f, 0.0f);
    Color3f sColor     = new Color3f(1.0f, 1.0f, 1.0f);
    Color3f coneColor  = new Color3f(0.9f, 0.1f, 0.1f);
    Color3f sphereColor= new Color3f(0.1f, 0.7f, 0.9f);
    Color3f bgColor    = new Color3f(0.0f, 0.0f, 0.0f);
    Color3f lightColor = new Color3f(1.0f, 1.0f, 1.0f);

    // Universe
    SimpleUniverse universe;

    public S3D() {
        setTitle("Stellate 3D");
        this.setLayout(new BorderLayout());   
 
        GraphicsConfiguration config =
           SimpleUniverse.getPreferredConfiguration();

        canvas = new Canvas3D(config);
        canvas.setSize(490,490);
       
        this.add("Center", canvas);
        
        // Create the scene. 
        createSceneGraph();

        // Add viewing platform  
        universe = new SimpleUniverse(canvas);
        universe.getViewingPlatform().setNominalViewingTransform();
        universe.addBranchGraph(rootBG);
        System.out.println("3D Canvas coming up");
        pack();
        show();
    }

    public void update(Vector triangles, boolean allfaces){
      Triangle t;
      System.out.println("S3D: Got " + triangles.size() + " Triangles");
      clear();
      stellBG = new BranchGroup();
      stellBG.setCapability(BranchGroup.ALLOW_DETACH);
      stellBG.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
      stellBG.addChild(makeTriangles(triangles, allfaces));
      sceneTG.addChild(stellBG);
    }

    public void clear(){
      if(stellBG != null){
        stellBG.detach();
        stellBG = null;
        canvas.repaint();
      }
    }

      public void createSceneGraph() {

      // Root of the branch grsph
      rootBG = new BranchGroup();
      rootBG.setCapability(BranchGroup.ALLOW_DETACH);
      rootBG.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
      rootBG.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
      rootBG.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);

      // Create transforms such that all objects appears in the scene
      sceneTransform = new Transform3D();
      sceneTransform.setScale(0.1f);
      Transform3D yrot = new Transform3D(); 
      yrot.rotY(-Math.PI/5.0d);
      sceneTransform.mul(yrot);
      sceneTG = new TransformGroup(sceneTransform);
      sceneTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
      sceneTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
      sceneTG.setCapability(TransformGroup.ALLOW_CHILDREN_WRITE);
      sceneTG.setCapability(TransformGroup.ALLOW_CHILDREN_READ);
      sceneTG.setCapability(TransformGroup.ALLOW_CHILDREN_EXTEND);

      rootBG.addChild(sceneTG);

      // Create bounds for the background and lights
      bounds =  new BoundingSphere(new Point3d(0.0,0.0,0.0), 100.0f);

      // Add mouse behaviors
      // Create the rotate behavior node
      MouseRotate rotBehavior = new MouseRotate();
      rotBehavior.setTransformGroup(sceneTG);
      sceneTG.addChild(rotBehavior);
      rotBehavior.setSchedulingBounds(bounds);

      // Create the zoom behavior node
      MouseZoom zoomBehavior = new MouseZoom();
      zoomBehavior.setTransformGroup(sceneTG);
      sceneTG.addChild(zoomBehavior);
      zoomBehavior.setSchedulingBounds(bounds);

      // Create the translate behavior node
      MouseTranslate transBehavior = new MouseTranslate();
      transBehavior.setTransformGroup(sceneTG);
      sceneTG.addChild(transBehavior);
      transBehavior.setSchedulingBounds(bounds);

      // Set up the background
      Background bg = new Background(bgColor);
      bg.setApplicationBounds(bounds);
      sceneTG.addChild(bg);

      // Create the transform group node for the lights 
      makeLight(new Vector3d(0.0, 0.0, -5.0));
      makeLight(new Vector3d(0.0, 5.0, 5.0));
      makeLight(new Vector3d(5.0, -5.0, 0.0));
      makeLight(new Vector3d(0.0, 0.0, 5.0));
      makeLight(new Vector3d(-5.0, 5.0, 0.0));

      // ambient light
      AmbientLight ambLight = new AmbientLight(aColor);
      ambLight.setInfluencingBounds(bounds);
      sceneTG.addChild(ambLight);

      baseBG = new BranchGroup();
      baseBG.setCapability(BranchGroup.ALLOW_DETACH);
      baseBG.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
      baseBG.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
      baseBG.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
      sceneTG.addChild(baseBG);

      // Create a cone and add it to the scene graph.
/*    Material m;
      Appearance a = new Appearance();

      m = new Material(coneColor, eColor, coneColor, sColor, 100.0f);
      m.setLightingEnable(true);
      a.setMaterial(m);
      Cone cone = new Cone(0.4f, 1.0f); 
      cone.setAppearance(a);
      baseBG.addChild(cone);

      // Create a sphere and add it to the scene graph.
      baseBG.addChild(
        makeSphere(new Vector3f(1.0f, 0.0f, 0.0f)));
*/
    }

    public TransformGroup makeTriangles(Vector triangles, boolean allfaces){
      int ntri = triangles.size();
      int nfaces = (allfaces?20:1);
      TriangleArray ta = 
        new TriangleArray(nfaces*3*ntri, 
          TriangleArray.COORDINATES | 
          TriangleArray.NORMALS | 
          TriangleArray.COLOR_3);
      double coord[] = new double[3];
      double l[] = new double[3];
      float norm[] = new float[3];
      Icosahedron ic = new Icosahedron();

      for(int face=0; face<nfaces; face++){

// normal for this face
        float total = 0.0f;
        for(int i=0; i<3; i++){
          norm[i] = 0.0f;
          for(int j=0; j<3; j++){
            norm[i] += ic.icosFace(face,j,i);
          }
          total += norm[i]*norm[i];
        }
        total = (float)Math.sqrt(total);
        for(int i=0; i<3; i++){
          norm[i] /= total;
        }

// color for this face
        Color3f color = new Color3f(ic.icosColor(face));

// geometry for this face
        for(int it=0; it<triangles.size(); it++){ // triangle
          Triangle t = (Triangle)triangles.elementAt(it);
          for(int iv=0; iv<3; iv++){ // vertex
            l = t.getHC(iv);
            for(int i=0; i<3; i++){
              coord[i] = 0.0;
              for(int j=0; j<3; j++){
                coord[i] += l[j]*ic.icosFace(face,j,i);
              }
            }
            ta.setCoordinate(face*ntri*3 + it*3+iv, coord);
            ta.setNormal    (face*ntri*3 + it*3+iv, norm);
            ta.setColor     (face*ntri*3 + it*3+iv, color);
          }
        }
      }

      Material m = new Material(
        sphereColor, eColor, sphereColor, sColor, 100.0f);
	m.setLightingEnable(true);
      Appearance a = new Appearance();
      a.setMaterial(m);

      PolygonAttributes pa = new PolygonAttributes();
      pa.setCullFace(PolygonAttributes.CULL_NONE);
      a.setPolygonAttributes(pa);

      Shape3D shapeta = new Shape3D(); 
      shapeta.setAppearance(a);
      shapeta.setGeometry(ta);

      TransformGroup triangleTG = new TransformGroup();
      triangleTG.addChild(shapeta);

      return triangleTG;
    }
        
    public TransformGroup makeSphere(Vector3f spherePos) {
      Transform3D sphereTrans = new Transform3D();
      sphereTrans.set(spherePos);
      TransformGroup sphereGroup = new TransformGroup(sphereTrans);
      
      Material m = new Material(
        sphereColor, eColor, sphereColor, sColor, 100.0f);
	m.setLightingEnable(true);
      Appearance a = new Appearance();
      a.setMaterial(m);
      Sphere sphere = new Sphere(0.1f); 
      sphere.setAppearance(a);
      sphereGroup.addChild(sphere);
      return sphereGroup;
    }

    public void makeLight(Vector3d lightPos) {
      Transform3D lightTransform = new Transform3D();
      lightTransform.set(lightPos);
      TransformGroup lightTransformGroup = new TransformGroup(lightTransform);
      sceneTG.addChild(lightTransformGroup);
      Light dirLight;
      Vector3f lightDir = new Vector3f(lightPos);
      lightDir.negate();
      Color3f lightColor = new Color3f(1.0f, 1.0f, 1.0f);
      dirLight = new DirectionalLight(lightColor, lightDir);
      dirLight.setInfluencingBounds(bounds);
      sceneTG.addChild(dirLight);
    }
}
