import java.awt.*;

// Stores a triangle in homogeneous coordinates
public class Triangle {
  HomoCoord hc;
  double h[][];

  public Triangle (HomoCoord hc) {
    this.hc = hc;
    h = new double[3][3];
    for(int i=0; i<3; i++)
      for(int j=0; j<3; j++)
        h[i][j] = (i==j) ? 1.0:0.0;
  }

  public Triangle (HomoCoord hc, double h[][]) {
    this.hc = hc;
    this.h = h;
  }

  public void addPoint(int vertex, double x, double y){
    double lp[] = hc.getHomoCoord(x, y);
    // System.out.println(lp[0] +" "+ lp[1] +" "+ lp[2]);
    for(int i=0; i<3; i++)
      h[vertex][i] = lp[i];
  }

  public double[] getHC(int vertex){
    return h[vertex];
  }
  
  public double getX(int vertex){
    return hc.getX(h[vertex]);
  }
  public double getY(int vertex){
    return hc.getY(h[vertex]);
  }

  public Triangle rotateClone () {
    double a, b, c;
    double m[][] = new double[3][3];
    for(int i=0; i<3; i++){
      a = h[i][0]; b = h[i][1]; c = h[i][2];
      m[i][0] = b; m[i][1] = c; m[i][2] = a;
    }
    return new Triangle(this.hc, m);
  }

  public Polygon getPolygon(){
    int ix[] = new int[3];
    int iy[] = new int[3];
    for(int i=0; i<3; i++){
      ix[i] = (int)getX(i);
      iy[i] = (int)getY(i);
    }
    return new Polygon(ix, iy, 3);
  }
}