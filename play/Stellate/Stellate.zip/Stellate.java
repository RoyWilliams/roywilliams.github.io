import java.applet.Applet;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import com.sun.j3d.utils.applet.MainFrame;

public class Stellate extends Applet implements ActionListener {

    // 3D Canvas
    S3D s3d;
    S2D s2d;

    // UI Components
    Button             update;
    Button             clear;

    Checkbox           icosym;
    Checkbox           rotsym;

    Checkbox           selectTriangles;
    Checkbox           selectVertices;

    public Stellate() {
        this.setLayout(new BorderLayout());   

        s3d = new S3D();

        s2d = new S2D();
        add("Center", s2d);

        Panel p = new Panel();
        p.setLayout(new GridLayout(4,1));

        Panel info = new Panel();
        info.setLayout(new GridLayout(2,1));
        info.add(new Label("Stellate: Icosahedral Stellation (Copyright Roy Williams 2000)"));
        info.add(new Label("For help and info, see http://www.cacr.caltech.edu/~roy/Stellate/"));
        p.add(info);

        Panel symp = new Panel();
        symp.setLayout(new GridLayout(1,3));
        symp.add(new Label("Symmetry: "));
        icosym = new Checkbox("Icosahedral", true);
        symp.add(icosym);
        rotsym = new Checkbox("Rotational", true);
        symp.add(rotsym);
        rotsym.addItemListener (
          new ItemListener() {
            public void itemStateChanged (ItemEvent e) {
              System.out.println("Rotational Symmetry " + rotsym.getState());
              s2d.rotsym(rotsym.getState());
            }
          }
        );
        p.add(symp);

        Panel clip = new Panel();
        clip.setLayout(new GridLayout(2,1));
        CheckboxGroup cg = new CheckboxGroup();
        selectTriangles = 
          new Checkbox("Click in a triangle to select it", cg, true);
        selectTriangles.addItemListener (
          new ItemListener() {
            public void itemStateChanged (ItemEvent e) {
              s2d.setSelectTriangles(selectTriangles.getState());
            }
          }
        );
        clip.add(selectTriangles);
        clip.add(new Label(""));
        selectVertices = 
          new Checkbox("Make triangles by clicking vertices", cg, false);
        selectVertices.addItemListener (
          new ItemListener() {
            public void itemStateChanged (ItemEvent e) {
              s2d.setSelectTriangles(selectTriangles.getState());
            }
          }
        );
        clip.add(selectVertices);
        p.add(clip);

        Panel buttons = new Panel();
        buttons.setLayout(new FlowLayout());
        update = new Button("Update 3D Canvas");
        buttons.add(update);
        update.addActionListener (this);
        clear = new Button("Clear All");
        buttons.add(clear);
        clear.addActionListener (this);
        p.add(buttons);

        add("North", p);

        s2d.addStandardTriangle(0);
        s2d.repaint();
        s3d.update(s2d.getTriangles(), icosym.getState());
    }

    public void actionPerformed (ActionEvent event) {
      Object source = event.getSource();
      if (source == update) {
        System.out.println("Update");
        s3d.update(s2d.getTriangles(), icosym.getState());
      }
      if (source == clear) {
        System.out.println("Clear");
        s2d.clear();
        s3d.clear();
      }
    }

    public static void main(String[] args) {
        Frame frame = new MainFrame(new Stellate(), 500, 600);
    }
}
