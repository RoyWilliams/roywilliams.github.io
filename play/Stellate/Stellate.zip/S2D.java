import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class S2D extends Canvas implements MouseListener {
  private Vector triangles;
  private HomoCoord hc;
  private Icosahedron icos;
  private boolean selectTriangles;

// following are for partially completed triangles
  private int nextpoint;
  private int x[];
  private int y[];

// set up stellation diagram
  double xt[] = {0.,0.,0.};
  double yt[] = {0.,0.,0.};
  int ixt[] = {0,0,0};
  int iyt[] = {0,0,0};
  Polygon[] standardPolyTriangles;
  Dimension oldCanvasSize;

// Rotatopn symmetry
  boolean rotsym;

  public S2D() {
    triangles = new Vector();
    x = new int[3];
    y = new int[3];
    nextpoint = 0;
    icos = new Icosahedron();
    addMouseListener(this);
    oldCanvasSize = new Dimension(0,0);
    selectTriangles = true;
    rotsym = true;
    setupStellation();
  }

  public void setSelectTriangles(boolean s){
    selectTriangles = s;
  }
  public void rotsym(boolean s){
    rotsym = s;
  }

  public void setupStellation(){
    Dimension canvasSize = this.getSize();
    double w = (double)canvasSize.width;
    double h = (double)canvasSize.height;
    double dimw = w/14.0;
    double dimh = h/12.0;
    double dim = (dimw<dimh) ? dimw:dimh;
    xt[0] = w/2 - dim;
    xt[1] = w/2 + dim;
    xt[2] = w/2;
    yt[0] = 2*h/3 - 0.577*dim;
    yt[1] = 2*h/3 - 0.577*dim;
    yt[2] = 2*h/3 + 1.155*dim;
    hc = new HomoCoord(xt, yt);

    standardPolyTriangles = new Polygon[67];
    for(int itri=0; itri<67; itri++){
      for(int iv=0; iv<3; iv++){
        ixt[iv] = (int)(
          icos.icosStell(itri, iv, 0)*xt[0] +
          icos.icosStell(itri, iv, 1)*xt[1] +
          icos.icosStell(itri, iv, 2)*xt[2]);
        iyt[iv] = (int)(
          icos.icosStell(itri, iv, 0)*yt[0] +
          icos.icosStell(itri, iv, 1)*yt[1] +
          icos.icosStell(itri, iv, 2)*yt[2]);
      }
      standardPolyTriangles[itri] = new Polygon(ixt, iyt, 3);
    }
  }

  public void paint(Graphics g) {
    Triangle p;
    Dimension canvasSize = this.getSize();
    if(canvasSize != oldCanvasSize){
      setupStellation();
      oldCanvasSize = canvasSize;
    }

    g.setColor(Color.blue);
    
    for(int itri=0; itri<67; itri++)
      g.drawPolygon(standardPolyTriangles[itri]);

    g.setColor(Color.red);
    for(int i=0; i<triangles.size(); i++){
      p = (Triangle)triangles.elementAt(i);
      g.fillPolygon(p.getPolygon());
    }

    g.setColor(Color.black);
    for(int i=0; i<nextpoint; i++)
      g.drawRect(x[i]-3, y[i]-3, 6, 6);
  }

  public Vector getTriangles(){
    return triangles;
  }

  public void addStandardTriangle(int itri){
    double hh[][] = new double[3][3];
    for(int i=0; i<3; i++){
      for(int j=0; j<3; j++){
        hh[i][j] = icos.icosStell(itri, i, j);
      }
    }
    triangles.addElement(new Triangle(hc, hh));
  }

  public void mousePressed(MouseEvent e) {
    if(selectTriangles){
      for(int itri=0; itri<67; itri++){
        if(standardPolyTriangles[itri].contains(e.getX(), e.getY())){
          addStandardTriangle(itri);
          if(rotsym){
            int newitri = itri;
            while(true){
              newitri = icos.nextTriangle(newitri);
              if(newitri == itri)
                break;
              addStandardTriangle(newitri);
            }
          }
        }
      }
    } else {
      x[nextpoint] = e.getX();
      y[nextpoint] = e.getY();
      nextpoint++;      
      if(nextpoint == 3){
        nextpoint = 0;
        Triangle p = new Triangle(hc);
        triangles.addElement(p);
        for(int i=0; i<3; i++)
          p.addPoint(i, (double)x[i], (double)y[i]);
        if(rotsym){
          p = p.rotateClone();
          triangles.addElement(p);
          p = p.rotateClone();
          triangles.addElement(p);
        }
      }
    }
    repaint();
  }

  public void clear() {
    triangles = new Vector();
    nextpoint = 0;
    repaint();
  }
  
  public void mouseEntered(MouseEvent e) {}   
  public void mouseExited(MouseEvent e) {}
  public void mouseClicked(MouseEvent e) {}
  public void mouseReleased(MouseEvent e) {}     
}